﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyLinkMysql
{
    public partial class Form6 : Form
    {
        string phoneNumber = "";
        public Form6()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            phoneNumber = textBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (phoneNumber == "")
                {
                    MessageBox.Show("   输 入 不 能 为 空", "45°炸同学录");
                    Form6 f6 = new Form6();
                    f6.Show();
                    this.Close();
                }
                else
                {

                    string constr = "server=" + Form1.ip + ";User Id=" + Form1.userId +
    ";password=" + Form1.password + ";Database=tongxuelu";
                    MySqlConnection mycon = new MySqlConnection(constr);
                    mycon.Open();
                    string sql = "delete from classmate where `电话号码`='" + phoneNumber + "'";


                    MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
                    DataSet ds = new DataSet();
                    mda.Fill(ds, "table2");
                    MessageBox.Show("   删 除 成 功！", "45°炸同学录");
                    Form2 f2 = new Form2();
                    f2.Show();
                    this.Close();
                    mycon.Close();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("出现了问题", "45°炸同学录");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Close();
            return;
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
    }
}
