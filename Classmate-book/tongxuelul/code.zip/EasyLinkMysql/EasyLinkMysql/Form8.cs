﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyLinkMysql
{

    public partial class Form8 : Form
    {
        string filename;
        public Form8()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /* try
             {
                 string constr = "server=" + Form1.ip + ";User Id=" + Form1.userId +
 ";password=" + Form1.password + ";Database=tongxuelu";
                 MySqlConnection mycon = new MySqlConnection(constr);
                 mycon.Open();
                 string sql = "SELECT * FROM classmate INTO OUTFILE 'C:/ProgramData/MySQL/MySQL Server 5.7/Uploads/" + filename + ".xls'";


                 MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
                 DataSet ds = new DataSet();
                 mda.Fill(ds, "table2");
                 //MessageBox.Show("   导 出 成 功！", "45°炸同学录");
                 Form2 f2 = new Form2();
                 f2.Show();
                 this.Close();


                 //导出excel
                 string str = "      导出成功！\nC:/ProgramData/MySQL/MySQL Server 5.7/Uploads/" + filename + ".xls";
                 MessageBox.Show(str, "Excel");
                 mycon.Close();
             }
             catch (Exception)
             {
                 MessageBox.Show("保存文件重名","45°炸同学录");
             }*/
            string constr = "server=" + Form1.ip + ";User Id=" + Form1.userId +
";password=" + Form1.password + ";Database=tongxuelu";
            MySqlConnection mycon = new MySqlConnection(constr);
            mycon.Open();
            string sql = "SELECT * FROM classmate";


            MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
            DataSet ds = new DataSet();
            mda.Fill(ds, "table2");
            DataSetToExcel(ds, true);
            
            Form2 f2 = new Form2();
            f2.Show();
            MessageBox.Show("导出成功");
            this.Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        //法三（速度最快）
        /// <summary>
        /// 将数据集中的数据导出到EXCEL文件
        /// </summary>
        /// <param name="dataSet">输入数据集</param>
        /// <param name="isShowExcle">是否显示该EXCEL文件</param>
        /// <returns></returns>
        public bool DataSetToExcel(DataSet dataSet, bool isShowExcle)
        {
            DataTable dataTable = dataSet.Tables[0];
            int rowNumber = dataTable.Rows.Count;//不包括字段名
            int columnNumber = dataTable.Columns.Count;
            int colIndex = 0;

            if (rowNumber == 0)
            {
                return false;
            }

            //建立Excel对象 
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            //excel.Application.Workbooks.Add(true);
            Microsoft.Office.Interop.Excel.Workbook workbook = excel.Workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
            Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];
            excel.Visible = isShowExcle;
            //Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)excel.Worksheets[1];
            Microsoft.Office.Interop.Excel.Range range;

            //生成字段名称 
            foreach (DataColumn col in dataTable.Columns)
            {
                colIndex++;
                excel.Cells[1, colIndex] = col.ColumnName;
            }

            for (int r = 0; r < rowNumber; r++)
            {
                for (int c = 0; c < columnNumber; c++)
                {
                    excel.Cells[r + 2, c + 1] = dataTable.Rows[r][c];
                }
            }


            

            return true;
        }

        
    }
}
