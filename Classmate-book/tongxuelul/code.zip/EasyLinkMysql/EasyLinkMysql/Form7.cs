﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyLinkMysql
{
    public partial class Form7 : Form
    {
        string userStr = "";
        string Sql_table = "";
        string temp = "";
        public Form7()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            temp = textBox2.Text;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
       
            Sql_table = comboBox1.SelectedItem.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        
           
            
                try
                {
                    if (userStr == "" || Sql_table == "" || temp == "")
                    {
                        MessageBox.Show("   输 入 不 能 为 空", "45°炸同学录");
                        Form7 f7 = new Form7();
                        f7.Show();
                        this.Close();
                    return;
                    }
                    else
                    {
                    //判断是否为空
                    string constr1 = "server=" + Form1.ip + ";User Id=" + Form1.userId +
        ";password=" + Form1.password + ";Database=tongxuelu";
                    MySqlConnection mycon1 = new MySqlConnection(constr1);
                    mycon1.Open();
                    string sql1 = "select * from classmate  where 电话号码='" + userStr + "'";

                    MySqlDataAdapter mda1 = new MySqlDataAdapter(sql1, mycon1);
                    DataSet ds1 = new DataSet();
                    mda1.Fill(ds1, "table1");
                    
                    DataTable dataTable = ds1.Tables[0];
                    if (dataTable.Rows[0][2] == null)
                    {
                        MessageBox.Show("    输 入 错 误！", "45°炸同学录");
                    }
                    else
                    {
                        string constr = "server=" + Form1.ip + ";User Id=" + Form1.userId +
            ";password=" + Form1.password + ";Database=tongxuelu";
                        MySqlConnection mycon = new MySqlConnection(constr);
                        mycon.Open();
                        string sql = "update classmate set " + Sql_table + "='" + temp + "' where 电话号码='" + userStr + "'";

                        MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
                        DataSet ds = new DataSet();
                        mda.Fill(ds, "table1");
                        Form2 f2 = new Form2();
                        f2.Show();


                        mycon.Close();
                        MessageBox.Show("    修 改 成 功！", "45°炸同学录");
                        this.Close();
                    }
                    }
                }
            catch(Exception)
            {
                MessageBox.Show("    输 入 错 误！", "45°炸团队");
            }
        
               
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            userStr = textBox1.Text;
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
    }
}
