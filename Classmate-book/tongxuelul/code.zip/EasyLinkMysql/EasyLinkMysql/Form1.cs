﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyLinkMysql
{
    public partial class Form1 : Form
    {
        public static string userId="";
        public static string password="";
        public static string ip = "localhost";

        public Form1()
        {
            InitializeComponent();
        }

        private void Start_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constr = "server=" + Form1.ip + ";User Id=" + userId +
               ";password=" + password + ";Database=tongxuelu";
            MySqlConnection mycon = new MySqlConnection(constr);
            bool CanConnectDB = false;
            //MySqlCommand mycmd = new MySqlCommand("insert into blog_category(cate_id,cate_name) values('90','abc')", mycon);
            try
            {
                mycon.Open();
                CanConnectDB = true;
                mycon.Close();
            }
            catch (Exception)
            {

            }
            if (CanConnectDB)
            {

                MessageBox.Show("      登 录 成 功！", "45°炸同学录");
                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("      用 户 名 密 码 错 误！或 连 接 超 时", "45°炸同学录");
            }

            /*
            try
            {
                mycon.Open();
                MessageBox.Show("数据库已经连接了！");
                string sql = "select * from tb_user";
                MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
                DataSet ds = new DataSet();
                mda.Fill(ds, "table1");
                //this.dataGridView1.DataSource = ds.Tables["table1"];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            */
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            userId = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            password = textBox2.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
