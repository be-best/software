﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EasyLinkMysql
{
    public partial class Form2 : Form
    {
        /*
         * 通讯录基本属性
         */
        /*
       string name;
       string phoneNumber;
       string qqNumber;
       string wecharNumber;
       string qqEmail;
       string homeAddr;
       string characteristicLanguage;
       */

   
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void skinButton5_Click(object sender, EventArgs e)
        {
            //导出到excel
            Form8 f8 = new Form8();
            f8.Show();
            this.Close();
            /*string constr = "server=" + Form1.ip + ";User Id=" + Form1.userId +
";password=" + Form1.password + ";Database=tongxuelu";
            MySqlConnection mycon = new MySqlConnection(constr);
            mycon.Open();
            string sql = "SELECT * FROM classmate";


            MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
            DataSet ds = new DataSet();
            mda.Fill(ds, "table2");
            DataSetToExcel(ds, true);*/
            
        }

        private void skinButton4_Click(object sender, EventArgs e)
        {
            //删除查询
            Form6 f6 = new Form6();
            f6.Show();
            this.Close();
        }

        private void skinButton3_Click(object sender, EventArgs e)
        {
            //修改通讯录
            Form7 f7 = new Form7();
            f7.Show();
            this.Close();
        }

        private void skinButton2_Click(object sender, EventArgs e)
        {
            //新的通讯录
            Form5 f5 = new Form5();
            f5.Show();
            this.Close();
        }

        private void skinButton1_Click(object sender, EventArgs e)
        {
            //完全查询
            Form3 f3 = new Form3();
            f3.Show();
            this.Close();
        }

        private void skinButton6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void skinButton7_Click(object sender, EventArgs e)
        {
            //精确查询
            Form4 f4 = new Form4();
            f4.Show();
            this.Close();
        }

        private void skinProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void skinButton8_Click(object sender, EventArgs e)
        {
            //关于
            MessageBox.Show("      作者： 45°炸 团队", "45°炸同学录");
        }
        //法三（速度最快）
        /// <summary>
        /// 将数据集中的数据导出到EXCEL文件
        /// </summary>
        /// <param name="dataSet">输入数据集</param>
        /// <param name="isShowExcle">是否显示该EXCEL文件</param>
        /// <returns></returns>
        public bool DataSetToExcel(DataSet dataSet, bool isShowExcle)
        {
            DataTable dataTable = dataSet.Tables[0];
            int rowNumber = dataTable.Rows.Count;//不包括字段名
            int columnNumber = dataTable.Columns.Count;
            int colIndex = 0;

            if (rowNumber == 0)
            {
                return false;
            }

            //建立Excel对象 
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            //excel.Application.Workbooks.Add(true);
            Microsoft.Office.Interop.Excel.Workbook workbook = excel.Workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
            Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1];
            excel.Visible = isShowExcle;
            //Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)excel.Worksheets[1];
            Microsoft.Office.Interop.Excel.Range range;

            //生成字段名称 
            foreach (DataColumn col in dataTable.Columns)
            {
                colIndex++;
                excel.Cells[1, colIndex] = col.ColumnName;
            }

            for (int r = 0; r < rowNumber; r++)
            {
                for (int c = 0; c < columnNumber; c++)
                {
                    excel.Cells[r + 2, c + 1] = dataTable.Rows[r][c];
                }
            }




            return true;
        }
    }
}
