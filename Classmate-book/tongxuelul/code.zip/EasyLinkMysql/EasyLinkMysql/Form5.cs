﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyLinkMysql
{
    public partial class Form5 : Form
    {
        string name = "";
        string phoneNumber = "";
        string qq = "";
        string wechatNumber = "";
        string homeAddr = "";
        string email = "";
        string userStr = "";


        public Form5()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //姓名
            name = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            //电话号码
            phoneNumber = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //qq
            qq = textBox3.Text;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //微信
            wechatNumber = textBox4.Text;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            //邮箱
            email = textBox5.Text;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            //家庭住址
            homeAddr = textBox6.Text;
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            //个性签名
            userStr = textBox7.Text;
        }

        private void skinButton1_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               if (name == "" || phoneNumber == "" ||
                    qq == "" || wechatNumber == "" ||
                    email == "" ||　homeAddr == "" ||
                    userStr == "")
                {
                    MessageBox.Show("   输 入 不 能 为 空", "45°炸同学录");
                    Form5 f5 = new Form5();
                    f5.Show();
                    this.Close();
                    return;
                }
                string constr = "server=" + Form1.ip + ";User Id=" + Form1.userId +
";password=" + Form1.password + ";Database=tongxuelu";
                MySqlConnection mycon = new MySqlConnection(constr);
                mycon.Open();
                String sql = "insert into classmate values('" + name + "','"
                                             + homeAddr + "','"
                                             + phoneNumber + "','"
                                             + wechatNumber + "','"
                                             + email + "','"
                                             + qq + "','"
                                             + userStr + "')";

                MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
                                DataSet ds = new DataSet();
                mda.Fill(ds, "table1");
                MessageBox.Show("   添 加 成 功！","45°炸同学录");
                Form2 f2 = new Form2();
                f2.Show();
                this.Close();
                mycon.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("出现了问题", "45°炸同学录");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Close();
        }
    }
}
