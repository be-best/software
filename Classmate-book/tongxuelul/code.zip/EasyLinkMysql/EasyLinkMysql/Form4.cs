﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyLinkMysql
{
    public partial class Form4 : Form
    {
        string userStr;
        
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constr = "server=" + Form1.ip + ";User Id=" + Form1.userId +
                ";password=" + Form1.password + ";Database=tongxuelu";
            MySqlConnection mycon = new MySqlConnection(constr);
            mycon.Open();
            string sql = "select * from classmate" + " where `姓名`= '" + userStr
                + "'";
            MySqlDataAdapter mda = new MySqlDataAdapter(sql, mycon);
            DataSet ds = new DataSet();
            mda.Fill(ds, "table");
            this.dataGridView1.DataSource = ds.Tables["table"];
            mycon.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            userStr = textBox1.Text;
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Close();
        }
    }
}
